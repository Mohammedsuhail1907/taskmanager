 
const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const taskController = require('../controllers/taskController');

 
router.get('/test', auth, (req, res) => {
    res.json({
        message: 'Task routes are working!',
        user: req.user
    });
});

 
router.post('/', auth, taskController.createTask);
router.get('/', auth, taskController.getAllTasks);
router.get('/:id', auth, taskController.getTaskById);
router.patch('/:id', auth, taskController.updateTask);
router.delete('/:id', auth, taskController.deleteTask);

module.exports = router;
