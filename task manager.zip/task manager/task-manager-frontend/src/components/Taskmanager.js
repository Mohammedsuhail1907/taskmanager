import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TaskManager.css';
import { useHistory } from 'react-router-dom';  

function TaskManager() {
    const [tasks, setTasks] = useState([]);
    const [newTaskDescription, setNewTaskDescription] = useState('');
    const [editingTaskId, setEditingTaskId] = useState(null);
    const [editedTaskDescription, setEditedTaskDescription] = useState('');
    const history = useHistory();  

    useEffect(() => {
        fetchTasks();
    }, []);

    const fetchTasks = async () => {
        try {
            const response = await axios.get('http://localhost:5000/tasks');
            setTasks(response.data);
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    };

    const handleAddTask = async () => {
        try {
            const response = await axios.post('http://localhost:5000/tasks', { description: newTaskDescription });
            setTasks([...tasks, response.data]);
            setNewTaskDescription('');
        } catch (error) {
            console.error('Error adding task:', error);
        }
    };

    const handleDeleteTask = async (taskId) => {
        try {
            await axios.delete(`http://localhost:5000/tasks/${taskId}`);
            setTasks(tasks.filter(task => task._id !== taskId));
        } catch (error) {
            console.error('Error deleting task:', error);
        }
    };

    const handleEditTask = (taskId, taskDescription) => {
        setEditingTaskId(taskId);
        setEditedTaskDescription(taskDescription);
    };

    const handleSaveTask = async (taskId) => {
        try {
            await axios.patch(`http://localhost:5000/tasks/${taskId}`, { description: editedTaskDescription });
            setTasks(tasks.map(task => {
                if (task._id === taskId) {
                    return { ...task, description: editedTaskDescription };
                }
                return task;
            }));
            setEditingTaskId(null);
            setEditedTaskDescription('');
        } catch (error) {
            console.error('Error updating task:', error);
        }
    };

    const redirectToLogin = () => {
        history.push('/login');  
    };

    return (
        <div className="task-manager">
            <h2>Task Manager</h2>
            <div className="task-form">
                <input 
                    type="text" 
                    value={newTaskDescription} 
                    onChange={(e) => setNewTaskDescription(e.target.value)} 
                    placeholder="Enter task description" 
                />
                <button onClick={handleAddTask}>Add Task</button>
            </div>
            <ul className="task-list">
                {tasks.map(task => (
                    <li key={task._id}>
                        {editingTaskId === task._id ? (
                            <>
                                <input 
                                    type="text" 
                                    value={editedTaskDescription} 
                                    onChange={(e) => setEditedTaskDescription(e.target.value)} 
                                />
                                <button onClick={() => handleSaveTask(task._id)}>Save</button>
                            </>
                        ) : (
                            <>
                                <span>{task.description}</span>
                                <button onClick={() => handleDeleteTask(task._id)}>Delete</button>
                                <button onClick={() => handleEditTask(task._id, task.description)}>Edit</button>
                            </>
                        )}
                    </li>
                ))}
            </ul>
            <button className="logout-button" onClick={redirectToLogin}>Logout</button>
        </div>
    );
}

export default TaskManager;
