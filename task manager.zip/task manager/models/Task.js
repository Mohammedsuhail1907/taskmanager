const express = require('express');
const router = express.Router();
const Task = require('../models/Task');

 
router.get('/tasks', async (req, res) => {
    try {
        const tasks = await Task.find({});
        res.json(tasks);
    } catch (error) {
        console.error('Error fetching tasks:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

 
router.post('/tasks', async (req, res) => {
    try {
        const { description, completed } = req.body;
        const task = new Task({ description, completed });
        await task.save();
        res.status(201).json(task);
    } catch (error) {
        console.error('Error creating task:', error);
        res.status(400).json({ error: 'Bad request' });
    }
});

 
router.put('/tasks/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { description, completed } = req.body;
        const task = await Task.findByIdAndUpdate(id, { description, completed }, { new: true });
        if (!task) {
            return res.status(404).json({ error: 'Task not found' });
        }
        res.json(task);
    } catch (error) {
        console.error('Error updating task:', error);
        res.status(400).json({ error: 'Bad request' });
    }
});

 
router.delete('/tasks/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const task = await Task.findByIdAndDelete(id);
        if (!task) {
            return res.status(404).json({ error: 'Task not found' });
        }
        res.json({ message: 'Task deleted successfully' });
    } catch (error) {
        console.error('Error deleting task:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
